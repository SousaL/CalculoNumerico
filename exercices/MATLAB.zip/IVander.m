function [c,v] = IVander(x,y,u)
%Entries
%x,y vectores coluna dos nodos
%u, valor ou vetor coluna de elementos
%entre x minimo e x maximo
%Saida:
%c, polinomio interpolador
%v, imagem de u pelo polinomio

m = length(x)-1;
X = MVander(x,m);
c = SLGauss(X,y);
v = VPol(c,u)