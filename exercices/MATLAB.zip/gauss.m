function [x] = gauss(A,b)

%fornece o vetor solu��o de um sistema quadrado SPD

[C] = escalonamento1(A,b)

[n,~] = size(C);

x = zeros(n,1);

for i = n:-1:1
    
    x(i) = (C(i,n+1) - C(i,1:n)*x)/C(i,i);


end

