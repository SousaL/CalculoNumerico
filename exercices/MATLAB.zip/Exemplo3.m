clear, clc

A = [2 -3 1; 1 1 -2;1 -2 2]
b = [4 5 0 ]'
x = GAUSS(A,b)