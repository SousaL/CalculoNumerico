clear
A = [4 -2; 2 1]

A =

     4    -2
     2     1

b = [8 0]'

b =

     8
     0

[x] = gauss(A,b)

C =

     4    -2     8
     0     2    -4


x =

     1
    -2
