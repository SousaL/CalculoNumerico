clear
clc
x = [0 1 4 6]';
y = [1 2.3 2.2 3.7]';
m=3;
X = MVander(x,m);
p3 = gauss(X,y)